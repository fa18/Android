package com.example.fabienfontaine.listedecourses;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AjoutMagasin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout_magasin);
    }
}
